import { f as r, t as A } from "./p-C7r5Gja6-brgxmFJL.js";
import { t as __exportAll } from "./leaflet.js";
//#region node_modules/@ionic/core/components/p-Uk13YgEc.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var p_Uk13YgEc_exports = /* @__PURE__ */ __exportAll({ mdTransitionAnimation: () => a });
var a = (a, o) => {
	const i = "40px", s = "back" === o.direction, n = o.leavingEl, e = A(o.enteringEl), c = e.querySelector("ion-toolbar"), p = r();
	if (p.addElement(e).fill("both").beforeRemoveClass("ion-page-invisible"), s ? p.duration((o.duration ?? 0) || 200).easing("cubic-bezier(0.47,0,0.745,0.715)") : p.duration((o.duration ?? 0) || 280).easing("cubic-bezier(0.36,0.66,0.04,1)").fromTo("transform", `translateY(${i})`, "translateY(0px)").fromTo("opacity", .01, 1), c) {
		const r$1 = r();
		r$1.addElement(c), p.addAnimation(r$1);
	}
	if (n && s) {
		p.duration((o.duration ?? 0) || 200).easing("cubic-bezier(0.47,0,0.745,0.715)");
		const a = r();
		a.addElement(A(n)).onFinish(((t) => {
			1 === t && a.elements.length > 0 && a.elements[0].style.setProperty("display", "none");
		})).fromTo("transform", "translateY(0px)", `translateY(${i})`).fromTo("opacity", 1, 0), p.addAnimation(a);
	}
	return p;
};
//#endregion
export { p_Uk13YgEc_exports as n, a as t };

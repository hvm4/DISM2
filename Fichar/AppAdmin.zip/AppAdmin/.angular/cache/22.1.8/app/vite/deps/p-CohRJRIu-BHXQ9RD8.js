import { f as e, p as h } from "./p-Ct2aBEue-BePt2maM.js";
import { t as d } from "./p-ZjP4CjeZ-BnW-oeAv.js";
import { t as __exportAll } from "./leaflet.js";
//#region node_modules/@ionic/core/components/p-CohRJRIu.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var p_CohRJRIu_exports = /* @__PURE__ */ __exportAll({
	MENU_BACK_BUTTON_PRIORITY: () => 99,
	OVERLAY_BACK_BUTTON_PRIORITY: () => 100,
	addCloseWatcherCondition: () => c,
	blockHardwareBackButton: () => i,
	shouldUseCloseWatcher: () => n,
	startHardwareBackButton: () => l,
	updateCloseWatcher: () => s
});
var n = () => e.get("experimentalCloseWatcher", !1) && void 0 !== d && "CloseWatcher" in d;
var i = () => {
	document.addEventListener("backbutton", (() => {}));
};
var r = [];
var a;
var c = (t) => {
	r.push(t);
};
var s = () => {
	a?.();
};
var l = () => {
	const e = document;
	let i = !1;
	const c = () => {
		if (i) return;
		let t = 0, n = [];
		const r = new CustomEvent("ionBackButton", {
			bubbles: !1,
			detail: { register(e, o) {
				n.push({
					priority: e,
					handler: o,
					id: t++
				});
			} }
		});
		e.dispatchEvent(r);
		const a = () => {
			if (n.length > 0) {
				let t = {
					priority: Number.MIN_SAFE_INTEGER,
					handler: () => {},
					id: -1
				};
				n.forEach(((e) => {
					e.priority >= t.priority && (t = e);
				})), i = !0, n = n.filter(((e) => e.id !== t.id)), (async (t) => {
					try {
						if (t?.handler) {
							const e = t.handler(a);
							null != e && await e;
						}
					} catch (t) {
						h("[ion-app] - Exception in startHardwareBackButton:", t);
					}
				})(t).then((() => i = !1));
			}
		};
		a();
	};
	if (e.addEventListener("backbutton", c), n()) {
		let e;
		a = () => {
			if (!r.some(((t) => t()))) return e?.destroy(), void (e = void 0);
			void 0 === e && (e = new d.CloseWatcher(), e.onclose = () => {
				e = void 0, c(), a?.();
			});
		}, a();
	}
};
//#endregion
export { s as i, n, p_CohRJRIu_exports as r, c as t };
